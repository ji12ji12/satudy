package interfaces;

public class GreetMain {
	public static void main(String[] args) {
		GoodnightGreeting ggg = new GoodnightGreeting();
		ggg.greeting();
		MorningGreeting mgg = new MorningGreeting();
		mgg.greeting();
	}
}
